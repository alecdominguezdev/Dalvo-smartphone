#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\cesar\develop\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\cesar\Desktop\Proyecto-Dalvosystem-Local\dalvo"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\cesar\Desktop\Proyecto-Dalvosystem-Local\dalvo\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=0.2.0"
export "FLUTTER_BUILD_NUMBER=2"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
