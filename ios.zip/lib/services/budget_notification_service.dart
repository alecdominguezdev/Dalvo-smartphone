import 'package:flutter/services.dart';
import 'dart:async';

class BudgetNotificationService {
  BudgetNotificationService._();
  static final BudgetNotificationService instance = BudgetNotificationService._();

  static const _channel = MethodChannel('dalvo/notifications');
  final _budgetTapController = StreamController<int?>.broadcast();

  Stream<int?> get budgetTaps => _budgetTapController.stream;

  Future<void> initialize() async {
    try {
      _channel.setMethodCallHandler((call) async {
        if (call.method == 'notificationTap' || call.method == 'openBudget') {
          final arguments = call.arguments;
          final budgetId = arguments is Map
              ? int.tryParse('${arguments['budgetId'] ?? arguments['id'] ?? ''}')
              : int.tryParse('$arguments');
          _budgetTapController.add(budgetId);
        }
      });
      await _channel.invokeMethod<void>('initialize');
    } catch (_) {
      // En Windows/iOS o builds anteriores el canal puede no estar disponible.
    }
  }

  Future<void> setBudgetBadge(int count) async {
    try {
      await _channel.invokeMethod<void>('setBudgetBadge', {'count': count});
    } catch (_) {}
  }

  Future<void> showNewBudget({required int count, int? budgetId}) async {
    try {
      await _channel.invokeMethod<void>('showNewBudget', {
        'count': count,
        if (budgetId != null) 'budgetId': budgetId,
      });
    } catch (_) {}
  }
}
